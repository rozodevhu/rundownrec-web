RunDownRec — placeholder build file
===================================

This archive stands in for a real client build so the download links, file
sizes, and checksums on the site all work end to end.

Replace it with your actual build:

  1. Drop your zip in the downloads/ folder of this repo, e.g.
       downloads\rundownrec-2024-11.zip
  2. Run the helper so it prints a ready-to-paste entry with size + SHA-256:
       .\scripts\add-file.ps1 downloads\rundownrec-2024-11.zip
  3. Paste that entry into data\clients.json (Clients tab) or
     data\special-clients.json (Special Clients tab).
  4. git add / commit / push. Cloudflare Pages republishes automatically.

Keep the download paths in the JSON relative to the site root, i.e. start
them with "downloads/". Cloudflare Pages caps individual files at 25 MB; if
a build is larger than that, host it on GitHub Releases instead and put the
full https:// URL in the file's "path".
